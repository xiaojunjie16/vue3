<template>
  <div class="father">
    <h3>父组件</h3>
    <h3>直接参考之前所讲的pinia即可</h3>
  </div>
</template>

<script setup lang="ts" name="Father">
</script>

<style scoped>
  .father{
    background-color: rgb(165, 165, 165);
    padding: 20px;
    border-radius: 10px;
  }
</style>
