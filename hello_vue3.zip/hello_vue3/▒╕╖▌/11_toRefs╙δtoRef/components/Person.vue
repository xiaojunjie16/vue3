<template>
  <div class="person">
    <h2>姓名:{{person.name}}</h2>
    <h2>年龄:{{person.age}}</h2>

    <button @click="changeName">修改名字</button>
    <button @click="changeAge">修改年龄</button>
  </div>
</template>

<script setup lang="ts" name="Person">
  import {reactive, toRefs, toRef} from 'vue'

  // 数据
  let person = reactive({
    name:'张三',
    age:18
  })

  let {name, age} = toRefs(person) //一次取很多
  let nl = toRef(person, 'name') //一个一个取
  console.log(nl.value)

  // 方法
  function changeName() {
    name.value += '~'
    console.log(name.value, person.name)
  }

  function changeAge() {
    age.value += 1
    console.log(age)
  }

</script>

<style scoped>
  .person {

    border-radius: 10px;
    background-color: skyblue;
    box-shadow: 0 0 10px;
    padding: 20px;
  }

  button{
    margin : 0 5px;
  }

  li {
    font-size: 20px;
  }
</style>
