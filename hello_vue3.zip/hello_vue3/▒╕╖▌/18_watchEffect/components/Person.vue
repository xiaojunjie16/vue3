<template>
  <div class="person">
    <h1>需求：水温达到50℃，或水位达到20cm，则联系服务器</h1>
    <h2 id="demo">水温：{{temp}}</h2>
    <h2>水位：{{height}}</h2>
    <button @click="changePrice">水温+1</button>
    <button @click="changeSum">水位+10</button>
  </div>
</template>

<script setup lang="ts" name="Person">
  import {ref, watch, watchEffect} from 'vue'

  //数据
  let temp = ref(0)
  let height = ref(0)

  //方法
  function changePrice(){
    temp.value += 10
  }

  function changeSum(){
    height.value += 1
  }

  //监视
  /*
  // 用watch实现，需要明确指出监视temp、height
  watch([temp, height], (value)=>{
    // 从value中获得最新的temp值、height值
    const [newTemp, newHeight] = value
    // 室温达到50℃，或者水位打到20cm，立即联系服务器
    if(newTemp >= 50 || newHeight >= 20){
      //console.log('联系服务器')
    }
  })
  */

  // 用watchEffect实现不用指明
  watchEffect(() => {
    if(temp.value >= 60 || height.value >= 80){
      console.log('给服务器发请求')
    }
  })
</script>

<style scoped>
  .person {

    border-radius: 10px;
    background-color: skyblue;
    box-shadow: 0 0 10px;
    padding: 20px;
  }

  button{
    margin : 0 5px;
  }

  li {
    font-size: 20px;
  }
</style>
