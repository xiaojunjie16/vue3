<template>
  <div class="person">

  </div>
</template>

<script setup lang="ts" name="Person">
  import {type PersonInter, type Persons} from '@/types'


  // let person:PersonInter =  {id:'aaa', name:'张三', age:60}

  let personList:Array<PersonInter> = [
    {id:'aaa', name:'张三', age:60},
    {id:'bbb', name:'李四', age:18},
    {id:'ccc', name:'王五', age:5}
  ]

</script>

<style scoped>
  .person {

    border-radius: 10px;
    background-color: skyblue;
    box-shadow: 0 0 10px;
    padding: 20px;
  }

  button{
    margin : 0 5px;
  }

  li {
    font-size: 20px;
  }
</style>
