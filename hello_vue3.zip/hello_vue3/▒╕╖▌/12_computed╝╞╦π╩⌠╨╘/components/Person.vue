<template>
  <div class="person">
    姓:<input type = "text" v-model = "firstname"> <br>
    名:<input type = "text" v-model = "lastname"> <br>
    <button @click="changeFullName">将全名改成li-si</button>
    全名:<span>{{fullName}}</span> <br>
    全名:<span>{{fullName}}</span> <br>
    全名:<span>{{fullName}}</span> <br>
    全名:<span>{{fullName}}</span> <br>
    全名:<span>{{fullName}}</span> <br>
  </div>
</template>

<script setup lang="ts" name="Person">
  import {ref, computed} from 'vue'
  let firstname = ref("zhang")
  let lastname = ref("san")

  // function fullName2() {
  //   console.log(1)
  //   return  firstname.value.slice(0, 1).toUpperCase() + firstname.value.slice(1) + '-' + lastname.value
  // }

  // // 这么定义的fullName是一个计算属性，且是只读的
  // let fullName = computed(() => {
  //   console.log(1)
  //   return  firstname.value.slice(0, 1).toUpperCase() + firstname.value.slice(1) + '-' + lastname.value
  // })

  // 这么定义的fullName是一个计算属性，可读可写
  let fullName = computed( {
    get(){
      return  firstname.value.slice(0, 1).toUpperCase() + firstname.value.slice(1) + '-' + lastname.value
    },
    set(val){
      const [str1, str2] = val.split('-')
      firstname.value = str1
      lastname.value = str2
    }
  })

  function changeFullName() {
    fullName.value = 'li-si'

  }
</script>

<style scoped>
  .person {

    border-radius: 10px;
    background-color: skyblue;
    box-shadow: 0 0 10px;
    padding: 20px;
  }

  button{
    margin : 0 5px;
  }

  li {
    font-size: 20px;
  }
</style>
