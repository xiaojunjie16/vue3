<template>
  <Person/>
</template>

<script lang="ts" setup name="App">
import Person from './components/Person.vue'
</script>