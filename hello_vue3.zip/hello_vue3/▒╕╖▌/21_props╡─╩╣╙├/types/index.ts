// 定义一个接口，限制每个Person对象的格式
export interface PersonInter {
    age: number,
    id: string,
    name: string
}

// 定义一个自定义类型Persons
export type Persons = PersonInter[]
