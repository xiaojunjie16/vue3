<template>
  <div class="person">
    <ul>
      <li v-for="p in list" :key="p.id">
        {{p.name}} -- {{p.age}}
      </li>
    </ul>
  </div>
</template>

<script lang="ts" setup name="Person">
import {defineProps} from 'vue'
import {Persons} from '@/types'
//const props = defineProps<{ list: Persons }>()

//接收a
// defineProps(['a'])

//接收a并保存
/*
  let x = defineProps(['a'])
  console.log(x.a)
 */

// 第一种写法：仅接收
// defineProps(['list'])
//接收并保存
// let x = defineProps(['list'])
// console.log(x.list)

// !!!!!tips: 不知道是不是WebStorm的问题，单独使用第一种写法一定会有list的读取问题，仅能读出name
// 但是加入如下语句可以解决写法一的问题const props = defineProps<{ list: Persons }>()

// 第二种写法：接收+限制类型
// defineProps<{list:Persons}>()

// 第三种写法：接收+限制类型+指定默认值+限制必要性
let props = withDefaults(defineProps<{list?:Persons}>(),{
  list:()=>[{id:'asdasg01',name:'小猪佩奇',age:18}]
})
console.log(props)
</script>

<style scoped>
.person {

  border-radius: 10px;
  background-color: skyblue;
  box-shadow: 0 0 10px;
  padding: 20px;
}

button{
  margin : 0 5px;
}

li {
  font-size: 20px;
}
</style>