<template>
<!--  <h2 a="1+1" :b="1+1" c="x" :d="x"></h2>-->
  <Person a="哈哈" :list="personList"/>
</template>

<script lang="ts" setup name="App">
import Person from './components/Person.vue'
import {reactive} from 'vue'
import {type Persons} from '@/types'

let x = 9

let personList = reactive<Persons>([
  {id:'e98219e12',name:'张三',age:18},
  {id:'e98219e13',name:'李四',age:19},
  {id:'e98219e14',name:'王五',age:20}
])
</script>