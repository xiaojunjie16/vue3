// 引入createApp用于创建应用
import {createApp} from 'vue'
// 引入App和组件
// @ts-ignore
import App from './App.vue'

createApp(App).mount('#app')